# Priya Nair
**Procurement Engineer - Mechanical Systems**

Bengaluru, Karnataka  
+91 98XXXX1008 | priya.nair@example.com

## Professional Summary
Procurement-focused mechanical engineer with vendor development, costing, and technical sourcing experience for industrial equipment. Understands drawings and BOMs well, but core work has been commercial rather than design or testing.

## Core Skills

- Vendor development
- BOM analysis
- Costing
- RFQ management
- SAP MM
- Negotiation
- Drawing interpretation
- Lead time planning
- Supplier evaluation
- Excel
- Quality follow-up
- Cross-functional communication

## Experience

### Procurement Engineer - MachFlow Equipments (Feb 2021 - Present)
- Handled sourcing of machined, fabricated, and bought-out items against engineering BOMs.
- Worked with quality and engineering teams on supplier deviations and alternate source approvals.
- Tracked cost reduction initiatives through vendor consolidation and drawing rationalisation.

### Supply Chain Intern - IndEquip Systems (Jul 2020 - Jan 2021)
- Supported RFQ comparison sheets and vendor follow-up for urgent requirements.

## Education

- B.Tech Mechanical Engineering, VTU, 2020

## Certifications

- Excel for Supply Chain Analytics